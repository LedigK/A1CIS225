#Write the code for a program that accepts data for an order number,
# customer name, length and width of the desk ordered, type of wood,
# and number of drawers. Display all the entered data and the final
# price for the desk.

a = 0
b = 0
c = 0

def customer():
    customer = input("Enter your first and last name: ")
    print ("Hello", customer, "!")

def total_price(surface_area, wood_type, drawer_number):
    base_price = 200

    if surface_area > 750:
        base_price = base_price + 50
    else:
        base_price = base_price + 0

    if wood_type == 1:
        base_price = base_price + 125
    if wood_type == 2:
        base_price = base_price + 150
    if wood_type == 3:
        base_price = base_price + 0
    if wood_type == 4:
        base_price = base_price + 0

    if drawer_number >= 0:
        base_price = base_price + (drawer_number * 30)

    total_price = base_price + surface_area

def wood_price():
    base_price = 0

    print("Your wood options are: " "1. Oak (+$125)" " " "2. Mahogany (+$150)" " " "3. Pine (+$0)" " " "4. Maple (+$0)")
    choice = int(input("Please enter your choice by number: "))
    return choice

def drawer_price():
    base_price = 0

    drawer_number = int(input("How many drawers would you like? Each drawer is an additional $50.00: "))
    return drawer_number

def surface_area():
    base_price = 0

    length = int(input("Enter the length of your desk: "))
    width = int(input("Enter the width of your desk: "))
    return length * width

customer()
desk_surface_area = surface_area()
desk_wood_type = wood_price()
desk_drawer_number = drawer_price()

print("Your total price is: $" + str(total_price(desk_surface_area, desk_wood_type, desk_drawer_number)))






